import React from 'react';
import {PropTypes} from "prop-types";
import {filterGrid, toggleActive, loadDataInGrid} from '../Actions';

class GridRecord extends React.Component {
    showUserDetails(e) {
        e.preventDefault();
        this.props.history.push(`/details/${this.props.record.id}`);
    }

    render() {
        let {record} = this.props;
        return <tr>
            <th onClick={this.showUserDetails.bind(this)}><a href="#">{record.id}</a></th>
            <th>{record.firstName}</th>
            <th>{record.lastName}</th>
            <th><input type="checkbox" checked={record.active} onChange={this.props.toggleActive}/></th>
        </tr>
    }
}

const Filter = ({value, onChange}) =>
    <p>
        <input type="text" placeholder="Filter by..."
               onChange={onChange}/>
    </p>;

export default class GridComponent extends React.Component {
    constructor() {
        super();
    }

    componentDidMount() {
        this.refs.filterInput && this.refs.filterInput.focus();
        this.loadData();
    }

    loadData() {
        let {dispatch} = this.props;
        dispatch(loadDataInGrid());
    }

    toggleActive(id) {
        let {dispatch} = this.props;
        dispatch(toggleActive(id));
    }

    updateLastName(index, newValue) {
        let {records} = this.props;
        records[index].lastName = newValue;
    }

    handleFilterChange(e) {
        let {dispatch} = this.props;
        dispatch(filterGrid(e.target.value));
    }

    render() {
        let recordsToShow = this.props.records.filter((record) => {
            return this.props.filtered.indexOf(record.id) == -1;
        });
        let records = recordsToShow.map(
            (record, index) => <GridRecord record={record}
                                           toggleActive={this.toggleActive.bind(this, record.id)}
                                           key={index}
                                           history={this.props.history}
            />
        );
        return (
            <div style={{width: 300, height: 300, padding: 20}}>
                <Filter onChange={this.handleFilterChange.bind(this)}/>
                <table className="table table-condensed">
                    <thead>
                    <tr>
                        <th>Id</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Active</th>
                    </tr>
                    </thead>

                    <tbody>
                    {records}
                    </tbody>
                </table>
                {this.props.children &&
                React.cloneElement(this.props.children, {records: this.props.records})}

            </div>
        )
    }
}
GridComponent.propTypes = {
    records: PropTypes.array.isRequired,
    filtered: PropTypes.array.isRequired,
    loading: PropTypes.bool.isRequired
};
