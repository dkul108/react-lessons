import * as React from "react";
import {Button, StyleSheet, Text, View} from "react-native";
import Drawer from "react-native-drawer";

/**
 * https://github.com/root-two/react-native-drawer
 */
class DrawerContent extends React.Component {
    render() {
        return (<View style={styles.drawerContent}>
            <View style={{width: 200}}>
                <Text>Content here</Text>
                <Button title="Close" onPress={this.props.closeDrawer}></Button>
            </View>
        </View>)
    }
}

export class Drawer001 extends React.Component {

    openDrawer() {
        //
        this.drawer.open();
    }

    closeDrawer() {
        this.drawer.close();
    }

    render() {

        return (<View style={styles.container}>
            <Drawer ref={e => this.drawer = e}
                    type="displace"
                    side="left"
                    acceptTap={true}
                    acceptPan={true}
                    openDrawerOffset={0.3}
                    tweenDuration={250}
                    content={<DrawerContent closeDrawer={() => this.closeDrawer()}/>}>
                <View>
                    <Text>Main View</Text>
                    <Button title="Open" onPress={() => this.openDrawer()}></Button>
                </View>
            </Drawer>
        </View>);
    }
}


let styles = StyleSheet.create({
    container: {
        flex: 1
    },
    drawerContent: {
        color: "white",
        flex: 1,
        backgroundColor: "grey",
        shadowColor: '#000000',
        shadowOpacity: 0.8,
        shadowRadius: 3
    }
})