import React from "react";
import {StyleSheet, Text, View} from "react-native";
/*
 Used internally inside other components
 */
const Box = (props) => {
    return (<View style={[styles.box, {width: props.width, height: props.height, backgroundColor: props.color}]}>
        <Text>{props.content}</Text>
    </View>);
}

Box.defaultProps = {
    width: 100,
    height: 100,
    color: "red",
    content: "Box"
}

let styles = StyleSheet.create({
    box: {
        borderColor: "black",
        borderWidth: 0.5
    }
});

export default Box;