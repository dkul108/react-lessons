import * as React from "react";
import {StyleSheet, Text, View} from "react-native";
import FlexBox from "./FlexBox";

class Layout000 extends React.Component {
    render() {
        return (<View style={styles.layout}>
           <FlexBox flex={0.25} content="Flex 0.25" color="yellow"></FlexBox>
           <FlexBox flex={0.50} content="Flex 0.50" color="pink"></FlexBox>
           <FlexBox flex={0.25} content="Flex 0.25"></FlexBox>
        </View>)
    }
}

let styles = StyleSheet.create({
    layout: {
        flex: 1,
        flexDirection: "column" // try "row"
    }
});

export default Layout000;