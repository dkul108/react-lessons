import React from 'react';
import {setState, getState, connect} from "./store";
import {PropTypes} from "prop-types";
import {filterList} from "./actions";

// When the filter input value changes. 
function onChange(e) {
    filterList(e.target.value);
}

// Renders a simple input element to filter a list. 
const MyInput = ({value, placeholder}) => (
    <input autoFocus
           value={value}
           placeholder={placeholder}
           onChange={onChange}/> );

MyInput.propTypes = {
    value: PropTypes.string,
    placeholder: PropTypes.string,
};

export default connect(MyInput);
