import * as React from "react";
import {StyleSheet, Switch, Text, View} from "react-native";

export class Switch001 extends React.Component {


    constructor(props) {
        super(props);
        this.state = {
            switchValue: false
        };
    }

    render() {

        return (<View style={styles.container}>

            <Switch style={styles.onoff}
                    value={this.state.switchValue}
                    onValueChange={(value) => this.setState({switchValue: value})}/>
            <Text>
                {this.state.switchValue ? "ON" : "OFF"}
            </Text>
        </View>);
    }
}

let styles = StyleSheet.create({
    container: {
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center"
    },
    onoff: {
        marginRight: 20
    }
})