import "bootstrap/dist/css/bootstrap.css"
import "./style.css"
import React from 'react';

import {Provider} from 'react-redux'
import configureStore from "./Store";
import GridContainer from "./Containers/grid";
import UserDetailsContainer from "./Containers/user-details";
import {Link, Route, Router, HashRouter, Switch} from "react-router-dom";

class Header extends React.Component {
    render() {
        return (
            <div>
                <h1>Our awesome app</h1>
                <ul role="nav">
                    <li><Link to="/grid">Grid</Link></li>
                    <li><Link to="/details">Details</Link></li>
                </ul>
                {this.props.children}
            </div>
        )
    }
}

const store = configureStore();

export default function App() {
    return (<Provider store={store}>
        <HashRouter>
            <div>
                <Header />
                <Switch>
                    <Route path="/grid" component={GridContainer}/>
                    <Route exact path="/details" component={UserDetailsContainer}/>
                    <Route path="/details/:id" component={UserDetailsContainer}/>
                </Switch>
            </div>
        </HashRouter>
    </Provider>)
}
