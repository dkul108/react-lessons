import * as React from "react";
import {AsyncStorage, Button, FlatList, Text, TextInput, View} from "react-native";

export class AsyncStorage001 extends React.Component {

    constructor(posts) {
        super(posts);
        this.state = {
            posts: []
        };
    }

    componentDidMount() {
        this.loadBlogs();
    }

    loadBlogs() {
        AsyncStorage.getItem("postList")
            .then((posts) => {
                return posts ? JSON.parse(posts) : [];
            })
            .then((posts) => {
                this.setState({posts});
            })
    }

    clearBlog() {
        AsyncStorage.removeItem("postList")
            .then(() => {
                this.loadBlogs();
            });
    }

    addBlog() {

        let post = {
            title: this.title
        }

        AsyncStorage.getItem("postList")
            .then((posts) => {
                return posts ? JSON.parse(posts) : [];
            })
            .then((posts) => {
                posts.push(post);
                return posts;
            })
            .then((posts) => {
                return AsyncStorage.setItem("postList", JSON.stringify(posts))
                    .then(() => {
                        return posts;
                    });
            })
            .then((posts) => {
                this.setState({posts});
            })

    }

    render() {
        return (<View>
            <TextInput onChangeText={title => this.title = title} multiline={true}
                       style={styles.input} autoFocus={true} placeholder={"Enter text"}></TextInput>
            <View style={{flexDirection: "row"}}>
                <Button title={"Add blog"} onPress={() => this.addBlog()}></Button>
                <Button title={"Clear"} onPress={() => this.clearBlog()}></Button>
            </View>
            <FlatList data={this.state.posts}
                      renderItem={({item}) => <Text>{item.title}</Text>}
            ></FlatList>
        </View>);
    }


}

const  styles = {
    input: {
        fontSize: 20
    }
}