
import {setState,getState} from "./store";
import {Dispatcher} from "./dispatcher";
import {fromJS} from "immutable";

let appDispatcher = new Dispatcher();

export function filterList( value ) {
    let payload = {
        type: 'FILTER_LIST',
        filter: value
    }
    appDispatcher.dispatch(payload);
}

appDispatcher.register(function(payload) {

    switch(payload.type) {

        case "FILTER_LIST":
            const state = getState();

            const items = state.get('items');
            const tempItems = state.get('tempItems');

            // The new state that we're going to set on the store. 
            let newItems;
            let newTempItems;
            if (payload.filter.length === 0) {
                // If input value is empty, restore from tempItems 
                newItems = tempItems;
                newTempItems = fromJS([]);
            } else {
                if (tempItems.isEmpty()) newTempItems = items;
                else newTempItems = tempItems;
                // Filter and set "newItems". 
                const filter = new RegExp(payload.filter, 'i');
                newItems = newTempItems.filter(i => filter.test(i));
            }
            // Updates the state of the store.
            setState(getState().merge({
                items: newItems,
                tempItems: newTempItems,
            }));
            break;

        default:
    }
});



