import * as React from "react";
import {Button, Dimensions, Modal, StyleSheet, Text, TextInput, View} from "react-native";
export class Modal001 extends React.Component {

    constructor(props) {
        super(props);
        this.state = {showModal: false};
    }

    showModal() {
        this.setState({showModal: true});
    }

    hideModal() {
        this.setState({showModal: false});
    }

    render() {
        let {width, height} = Dimensions.get("window");
        let modalSize = {
            width: width / 1.3,
            height: height / 2.3
        };
        return (<View>
            <TextInput onChangeText={(text) => this.setState({text})}
                       style={styles.input} autoFocus={true} placeholder={"Enter text"}></TextInput>
            <Button title={"Show modal"} onPress={() => this.showModal()}></Button>
            <Modal animationType={"fade"}
                   transparent={true}
                   onRequestClose={() => this.hideModal()}
                   visible={this.state.showModal}>
                <View style={styles.modalOuter}>
                    <View style={[styles.modalInside, modalSize]}>
                        <View style={styles.modalClose}>
                            <Button color="white" title={"✖"} onPress={() => this.hideModal()}></Button>
                        </View>
                        <Text style={styles.modalText}>{this.state.text}</Text>
                    </View>

                </View>
            </Modal>
        </View>);
    }
}

let styles = StyleSheet.create({
    modalOuter: {
        backgroundColor: "rgba(0,0,0,0.2)",
        justifyContent: "center",
        alignItems: "center",
        flex: 1
    },
    modalInside: {
        backgroundColor: "#dcdcdc",
        padding: 10,
        borderRadius: 5,
        borderWidth: 1
    },
    modalClose: {
        flexDirection: "row",
        justifyContent: "flex-end"
    },
    modalText: {
        color: "black"
    },
    input: {
        fontSize: 20
    }
});
