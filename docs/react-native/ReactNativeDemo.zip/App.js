import React, {Component} from "react";
import {StyleSheet, View} from "react-native";
import {NativeRouter} from "react-router-native";
import {Route} from "react-router";
import Layout003 from "./components/Layout003";
import Layout001 from "./components/Layout001";
import Layout002 from "./components/Layout002";
import PickRoute from "./components/PickRoute";
import {Dimensions001} from "./components/Dimensions001";
import {Alert001} from "./components/Alert001";
import {Vibration001} from "./components/Vibration001";
import {Clipboard001} from "./components/Clipboard001";
import {Modal001} from "./components/Modal001";
import {WebView001} from "./components/WebView001";
import {Image001} from "./components/Image001";
import {Switch001} from "./components/Switch001";
import {FlatList001} from "./components/FlatList001";
import {Drawer001} from "./components/Drawer001";
import {AsyncStorage001} from "./components/AsyncStorage001";
import Layout000 from "./components/Layout000";
import {NetInfo001} from "./components/NetInfo001";

const routes = [
    Layout000,
    Layout001,
    Layout002,
    Layout003,
    Dimensions001,
    Alert001,
    Vibration001,
    Clipboard001,
    Modal001,
    WebView001,
    Image001,
    Switch001,
    FlatList001,
    Drawer001,
    AsyncStorage001,
    NetInfo001
];

export default class ReactNativeDemo extends Component {

    render() {
        return (
            <NativeRouter>
                <View style={styles.container}>
                    <PickRoute routes={routes}/>
                    <Route exact={true} path={"/"} component={routes[0]}></Route>

                    {routes.map((comp) => {
                        let name = comp.name;
                        return <Route key={name} path={`/${name}`} component={comp}></Route>;
                    })}
                </View>
            </NativeRouter>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1
    }
});
