/**
 * <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
 */
import * as React from "react";
import {Text, View} from "react-native";
import NetInfo from "@react-native-community/netinfo";


export class NetInfo001 extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isConnected: false,
            connectionType: "UNKNOWN"
        };

        this.handleConnection = this.handleConnection.bind(this);
    }

    handleConnection(state) {
        this.setState({connectionType: state.type});
        NetInfo.fetch().then(state => {
            this.setState({isConnected: state.isConnected});
        });
    }

    componentDidMount() {
        NetInfo.fetch().then(this.handleConnection);
        this.unsubscribe = NetInfo.addEventListener('change', this.handleConnection); // connection listener
    }

    componentWillUnmount() {
        this.unsubscribe();
    }

    render() {

        let {isConnected, connectionType} = this.state;

        return (<View>
            <Text style={{backgroundColor: isConnected ? "green" : "red"}}>
                {isConnected ? "Internet connected!" : "No internet connection!"}
            </Text>
            <Text>
                {connectionType}
            </Text>
        </View>);
    }
}