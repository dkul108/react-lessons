import * as React from "react";
import {Button, Clipboard, StyleSheet, TextInput, ToastAndroid, View} from "react-native";

export class Clipboard001 extends React.Component {

    copy(content) {
        Clipboard.setString(content);
        alert(`Copied content: ${content}`);
    }

    async paste() {
        const string = await Clipboard.getString();
        alert(string);
    }

    render() {
        return (<View>
            <View style={styles.copyPaste}>
                <View style={styles.flex7}>
                    <TextInput onChangeText={(text) => this.text = text}
                               style={styles.input} autoFocus={true}
                               placeholder={"Enter text"}></TextInput>
                </View>
                <View style={styles.flex3}>
                    <Button title={"Copy"} onPress={() => this.copy(this.text)}></Button>
                </View>

            </View>
            <View style={styles.copyPaste}>
                <View style={styles.flex3}>
                    <Button title={"Show copied"} onPress={this.paste}></Button>
                </View>
            </View>

        </View>);
    }
}

let styles = StyleSheet.create({
    copyPaste: {
        flexDirection: "row",
        justifyContent: "space-between"
    },
    flex3: {
        flex: 3
    },
    flex7: {
        flex: 7
    },
    input: {
        fontSize: 20
    }
});