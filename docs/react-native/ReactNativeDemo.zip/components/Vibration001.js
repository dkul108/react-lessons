import * as React from "react";
import {Button, Vibration, View} from "react-native";

/**
 * Requires vibration permission
 * <uses-permission android:name="android.permission.VIBRATE"/>
 */
export class Vibration001 extends React.Component {

    componentDidMount() {

    }

    render() {
        return (<View>
            <Button title="Vibrate" onPress={() => Vibration.vibrate()}></Button>
        </View>);
    }
}