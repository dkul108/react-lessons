import React from 'react';
import ConnectedInput from "./MyInput";
import ConnectedList from "./MyList";
import {setState,getState,connect} from "./store";
import { render } from 'react-dom';

// Setup the default store state...
setState(getState().merge({
    placeholder: 'Search...',
    items: ['First', 'Second', 'Third', 'Fourth'],
    tempItems: [],
}));


render((
        <section>
            <ConnectedInput />
            <ConnectedList />
        </section>
    ), document.getElementById('app')
);