import React, {useState,useReducer} from 'react';
import {render} from 'react-dom';

function listReducer(state, action) {
	switch (action.type) {
		case 'add':
			return [action.value, ...state];
		case 'remove':
			return state.filter((v,i)=>i!==action.index);
		default:
			throw new Error();
	}
}

function List() {
	const [value, setVal] = useState("");
	const [list, dispatch] = useReducer(listReducer, []);
	const listItems = list.map((v,i)=>
		<li key={i}>
			{v}
			<button onClick={()=>dispatch({type: 'remove', index:i})}>x</button>
		</li>);
	return (
		<div>
			<input value={value} onChange={e => setVal(e.target.value)}/>
			<button onClick={()=>{dispatch({type: 'add', value}); setVal("")}}>Add</button>
			<ul>
				{listItems}
			</ul>
		</div>
	);
};

function Counter({initialCount}) {
	const [count, setCount] = useState(initialCount);
	return (
		<p>
			Счёт: {count}
			<button onClick={() => setCount(initialCount)}>Сбросить</button>
			<button onClick={() => setCount(prevCount => prevCount + 1)}>+</button>
			<button onClick={() => setCount(prevCount => prevCount - 1)}>-</button>
		</p>
	);
}

const App = ()=>
	<div>
		<Counter initialCount={3}/>
		{/*<List />*/}
	</div>;

render(
    <App />
    ,document.getElementById('app')
);
