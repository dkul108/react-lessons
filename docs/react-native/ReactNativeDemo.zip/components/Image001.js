import * as React from "react";
import {Image, StyleSheet, View} from "react-native";

export class Image001 extends React.Component {


    render() {

        return (<View style={styles.container}>
            <Image
                style={styles.image}
                source={{uri: "https://kodedu.com/wp-content/uploads/2017/02/kodedu-logo.png"}}></Image>
        </View>);
    }
}

let styles = StyleSheet.create({
    container:{
      flex: 1,
      justifyContent: "center",
      alignItems: "center"
    },
    image: {
        width: 329, height: 100,
        borderWidth: 2,
        borderColor: "black"
    }
});