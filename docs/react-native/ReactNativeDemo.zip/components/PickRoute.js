import {Picker, StyleSheet} from "react-native";
import * as React from "react";
import {withRouter} from "react-router";


class PickRoute extends React.Component {

    constructor(props) {
        super(props);
        this.state = {};
    }

    render() {
        return (<Picker style={styles.routePicker} selectedValue={this.state.pickerValue}
                        onValueChange={(value) => {
                            this.setState({pickerValue: value})
                            this.props.history.push(value);
                        }}>
            {this.props.routes.map(comp => {
                let name = comp.name;
                return (<Picker.Item key={name}
                                     label={name} value={name}></Picker.Item>)
            })}
        </Picker>);
    }
}

const styles = StyleSheet.create({
    routePicker: {
        backgroundColor: "pink",
        color: "black",
        borderColor: "black",
        borderWidth: 2,
        marginBottom: 5
    }
});

export default withRouter(PickRoute);