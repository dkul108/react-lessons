import * as React from "react";
import {Dimensions, Text, View} from "react-native";

export class Dimensions001 extends React.Component {

    constructor() {
        super();
        this.state = {
            dimensions: {}
        }
    }

    onLayout() {
        let dimensions = Dimensions.get("window")
        this.setState({
            dimensions
        })
    }

    render() {
        return (<View onLayout={() => this.onLayout()}>
            <Text>
                {JSON.stringify(this.state.dimensions)}
            </Text>
        </View>);
    }
}