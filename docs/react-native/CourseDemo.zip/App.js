import React, {useState} from 'react';
import {StyleSheet, Text, View, ScrollView, Alert} from 'react-native';
import {ThemeProvider, Button, Input, ListItem} from "react-native-elements";

export default function App() {

    const [text, setText] = useState("");
    const [todos, setTodos] = useState([]);
    const [editMode, setEditMode] = useState({});

    function clearTodo() {
        setTodos([]);
        setEditMode({})
        setText("");
    }

    function addTodo() {
        setTodos([...todos, text]);
        setText("");
    }

    function deleteTodo(index) {
        let newTodos = [...todos];
        newTodos.splice(index, 1);
        setTodos(newTodos);
    }

    function enterEdit(index) {
        let newState = {...editMode};
        newState[index] = true;
        setEditMode(newState);
    }

    function editTodo(text, index) {
        let newTodos = [...todos];
        newTodos[index] = text
        setTodos(newTodos);
    }

    function exitEditMode(index) {
        let newState = {...editMode};
        newState[index] = false;
        setEditMode(newState);
    }

    function showAlert(todo, index) {
        Alert.alert(
            'Alert Title',
            'My Alert Msg',
            [
                {text: 'Delete', onPress: () => deleteTodo(index)},
                {text: 'Edit', onPress: () => enterEdit(index)},
                {text: 'Cancel', style: 'cancel', onPress: () => console.log('OK Pressed')},
            ],
            {cancelable: false}
        );
    }

    return (
        <ThemeProvider>
            <ScrollView style={styles.scroll}>
                <View style={styles.container}>
                    <View style={styles.input}>
                        <Input onChangeText={setText}
                               autoFocus={true}
                               value={text}/>
                    </View>
                    <View style={styles.button}>
                        <Button onPress={() => addTodo()} title={"Add"}></Button>
                    </View>
                    <View style={styles.button}>
                        <Button onPress={clearTodo} title={"Clear"}></Button>
                    </View>
                </View>
                {
                    todos.map((todo, index) => {
                            if (editMode[index]) {
                                return <Input value={todo}
                                              onChangeText={(text) => editTodo(text, index)}
                                              onBlur={() => exitEditMode(index)}
                                              autoFocus={true}/>
                            } else {
                                return <ListItem
                                    key={todo}
                                    title={todo}
                                    onLongPress={() => showAlert(todo, index)}
                                    bottomDivider
                                />
                            }
                        }
                    )
                }
                <View>
                    <Text style={styles.todoSize}>Todo size: {todos.length}</Text>
                </View>
            </ScrollView>
        </ThemeProvider>
    );
}

const styles = StyleSheet.create({
    scroll: {
        paddingTop: 50,
        paddingBottom: 50,
        paddingLeft: 10,
        paddingRight: 10,
        flex: 1
    },
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: "row"
    },
    input: {
        flex: 6,
        fontSize: 20
    },
    button: {
        flex: 2
    },
    todoSize: {
        paddingLeft: 10,
        fontSize: 18,
        color: "#8d8d8d"
    }
});
