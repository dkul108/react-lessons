import * as React from "react";
import {StyleSheet, View} from "react-native";
import Box from "./Box";

class Layout002 extends React.Component {
    render() {
        return (<View style={styles.layout}>
            <Box></Box>
            <Box color="yellow"></Box>
            <Box color="pink"></Box>
        </View>)
    }
}

let styles = StyleSheet.create({
    layout: {
        flex: 1,
        flexDirection: "column", // try "row"
        justifyContent: "center" // try "flex-start" , "flex-end" , "center" , "space-around" , "space-between"
    }
});

export default Layout002;