import * as React from "react";
import {StyleSheet, View} from "react-native";
import WebView from "react-native-webview";

export class WebView001 extends React.Component {


    render() {

        return (<View style={styles.container}>
            <WebView javaScriptEnabled={true}
                     domStorageEnabled={true}
                     startInLoadingState={true}
                     source={{uri: "https://kodedu.com"}}></WebView>
        </View>);
    }
}


let styles = StyleSheet.create({
    container: {
        flex: 1
    }
})