import React, {useState,useReducer} from 'react';
import {render} from 'react-dom';

const useInput = initialValue => {
	const [value, setValue] = useState(initialValue);

	return {
		value,
		setValue,
		reset: () => setValue(""),
		bind: {
			value,
			onChange: event => {
				setValue(event.target.value);
			}
		}
	};
};


function listReducer(state, action) {
	switch (action.type) {
		case 'add':
			return [action.value, ...state];
		case 'remove':
			return state.filter((v,i)=>i!==action.index);
		default:
			throw new Error();
	}
}

const useList = initialValue => {
	const [list, dispatch] = useReducer(listReducer, initialValue);

	return {
		list,
		add: value => dispatch({type: 'add', value}),
		remove: i=>dispatch({type: 'remove', index:i})
	};
};

function List() {
	const { value, bind, reset } = useInput('');
	const { list, add, remove } = useList([]);
	const listItems = list.map((v,i)=>
		<li key={i}>
			{v}
			<button onClick={()=>remove(i)}>x</button>
		</li>);
	return (
		<div>
			<input {...bind} />
			<button onClick={()=>{add(value); reset();}}>Add</button>
			<ul>
				{listItems}
			</ul>
		</div>
	);
};


const App = ()=>
	<div>
		<List />
	</div>;

render(
    <App />
    ,document.getElementById('app')
);
