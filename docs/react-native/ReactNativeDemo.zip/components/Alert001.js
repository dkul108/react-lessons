import * as React from "react";
import {Button, TextInput, View} from "react-native";

export class Alert001 extends React.Component {

    render() {
        return (<View>
            <TextInput
                autoFocus={true}
                style={{fontSize: 20}}
                onChangeText={(text) => this.setState({text})}
                placeholder={"Enter text"}></TextInput>
            <Button
                title={"Alert input text"}
                onPress={() => alert(this.state.text)}></Button>
        </View>);
    }
}