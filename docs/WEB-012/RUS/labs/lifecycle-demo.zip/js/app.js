import "bootstrap/dist/css/bootstrap.css";
import React from 'react';
import {render} from 'react-dom';
class TextInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            firstName: props.firstName
        }
    }

    static getDerivedStateFromProps(nextProps, nextState) {
        if (!nextProps.forceUpdate) return null;
        return {
            ...nextState,
            firstName : nextProps.firstName };
    }

    updateFirstName(event) {
        this.setState({firstName: event.target.value})
    }

    componentWillUnmount() {
        console.log("unmounting");
    }

    render() {
        return <input value={this.state.firstName}
           onChange={this.updateFirstName.bind(this)}/>
    }
}


class Container extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            firstName: "Vasya",
            forceUpdate: false
        }
    }

    updateFirstName(event) {
        this.setState({firstName: event.target.value})
    }

    updateForceUpdate(event) {
        this.setState({forceUpdate: !this.state.forceUpdate})
    }


    render() {
        let textInput = this.state.firstName.length==0 ? null :
            <TextInput firstName={this.state.firstName}
                       forceUpdate={this.state.forceUpdate}
            />;

        return (
            <div>
                First name:
                <input type="text"
                    value={this.state.firstName}
                    onChange={this.updateFirstName.bind(this)}/>
                <input type="checkbox"
                    onChange={this.updateForceUpdate.bind(this)}
                /> force
                <br/>
                {textInput}
            </div>
        )
    }
}

render(
    <Container/>,
    document.getElementById('app')
);
