import React from "react";
import {StyleSheet, Text, View} from "react-native";

const FlexBox = (props) => {
    return (<View style={[styles.box, {flex: props.flex, backgroundColor: props.color}]}>
        <Text>{props.content}</Text>
    </View>);
}

FlexBox.defaultProps = {
    flex: 1,
    color: "red",
    content: "Box"
}

let styles = StyleSheet.create({
    box: {
        borderColor: "black",
        borderWidth: 0.5,
        padding: 10
    }
});

export default FlexBox;