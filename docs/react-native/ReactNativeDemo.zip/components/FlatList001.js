import * as React from "react";
import {Button, FlatList, StyleSheet, Text, TextInput, View} from "react-native";

export class FlatList001 extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            list: []
        };
    }

    addToList() {
        this.setState({
            list: [...this.state.list, {text: this.text}]
        });
    }

    render() {

        return (<View style={styles.container}>
            <View>
                <TextInput onChangeText={(text) => this.text = text}
                           style={styles.input}
                           autoFocus={true} clearTextOnFocus={true}></TextInput>
                <Button onPress={() => this.addToList()} title="Add to List"></Button>
            </View>
            <FlatList
                data={this.state.list}
                renderItem={({item}) => <Row>
                    <Text>{item.text}</Text>
                </Row>}
            />

        </View>);
    }
}

let Row = (props) => {
    return (<View style={styles.row}>
        {props.children}
    </View>)
}

let styles = StyleSheet.create({
    container: {
        flex: 1
    },
    input: {
        fontSize: 20
    },
    row: {
        borderWidth: 1,
        borderColor: "rgba(0,0,0,0.2)",
        marginBottom: 2,
        backgroundColor: "rgba(0,0,0,0.1)",
        height: 30,
        paddingLeft: 5
    }
})